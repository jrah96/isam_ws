#!/usr/bin/env python3

import os
import sys

# Activate the virtual environment if not already activated
venv_path = os.path.expanduser('~/isam_ws/venvs/stepper_control_venv/bin/activate_this.py')
if 'VIRTUAL_ENV' not in os.environ:
    exec(open(venv_path).read(), {'__file__': venv_path})

import rclpy
from rclpy.node import Node
import RPi.GPIO as GPIO
import time

#Use BOARD numbering
GPIO.setmode(GPIO.BOARD)

# Define your GPIO pins here
STEPPER_PINS = {
    1: {'step': 11, 'dir': 13},  # Motor 1
    2: {'step': 15, 'dir': 16},  # Motor 2
    3: {'step': 18, 'dir': 22},  # Motor 3
}

class StepperController(Node):
    def __init__(self):
        super().__init__('stepper_controller')

        # Set up GPIO
        GPIO.setmode(GPIO.BOARD)
        for motor_id, pins in STEPPER_PINS.items():
            GPIO.setup(pins['step'], GPIO.OUT)
            GPIO.setup(pins['dir'], GPIO.OUT)

        # Declare parameters for motor selection and angle
        self.declare_parameter('motor_id', 1)
        self.declare_parameter('angle', 0.0)

        # Create a timer to check and apply the parameters periodically
        self.create_timer(1.0, self.timer_callback)

    def timer_callback(self):
        motor_id = self.get_parameter('motor_id').get_parameter_value().integer_value
        angle = self.get_parameter('angle').get_parameter_value().double_value

        if motor_id in STEPPER_PINS:
            self.move_motor(motor_id, angle)
        else:
            self.get_logger().error(f"Invalid motor_id: {motor_id}. Please select 1, 2, or 3.")

    def move_motor(self, motor_id, angle):
        # Calculate the number of steps needed to achieve the desired angle
        steps_per_revolution = 200  # Change according to your motor
        steps = int((steps_per_revolution / 360) * angle)

        direction = GPIO.HIGH if steps > 0 else GPIO.LOW
        steps = abs(steps)

        GPIO.output(STEPPER_PINS[motor_id]['dir'], direction)

        for _ in range(steps):
            GPIO.output(STEPPER_PINS[motor_id]['step'], GPIO.HIGH)
            time.sleep(0.001)  # Adjust for your motor's speed
            GPIO.output(STEPPER_PINS[motor_id]['step'], GPIO.LOW)
            time.sleep(0.001)

        self.get_logger().info(f"Moved Motor {motor_id} by {angle} degrees.")

    def __del__(self):
        GPIO.cleanup()

def main(args=None):
    rclpy.init(args=args)
    node = StepperController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
