#!/usr/bin/env python3
import os 
import sys

venv_path = os.path.expanduser('~/isam_ws/venvs/servo_control_venv/bin/activate_this.py')
exec(open(venv_path).read(), {'__file__': venv_path})

import rclpy
from rclpy.node import Node 
from adafruit_servokit import ServoKit

class ServoController(Node):
    def __init__(self):
        super().__init__('servo_controller')
        self.servo_kit = ServoKit(channels=16)
        self.declare_parameter('servo_channel', 0)
        self.declare_parameter('servo_position', 0)
        self.create_timer(1.0, self.timer_callback)

    def timer_callback(self):
        channel = self.get_parameter('servo_channel').get_parameter_value().integer_value
        position = self.get_parameter('servo_position').get_parameter_value().integer_value
        self.move_servo(channel, position)
    
    def move_servo(self, channel, position):
        self.servo_kit.servo[channel].angle = position

def main(args=None):
    rclpy.init(args=args)
    node = ServoController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
