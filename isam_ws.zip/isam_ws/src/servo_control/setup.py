from setuptools import find_packages, setup

package_name = 'servo_control'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='isamrpi',
    maintainer_email='isamrpi@todo.todo',
    description='ROS2 Package to Control Servos Using the PCA9685.',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'servo_controller = servo_control.servo_controller:main',
        ],
    },
)